package WEB_SITE;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Vector;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

public class Service_wb {

	
	public static Connection mycon() {
		
		Connection con = null;
		
		try {
			
			FileInputStream f = new FileInputStream("C:\\Users\\USER\\eclipse-workspace\\WEB\\src\\main\\java\\WEB_SITE\\jdbc.properties");
			 Properties p = new Properties();
			    p.load(f);
			    
			    
			    Class.forName(p.getProperty("jdbc.driver")).newInstance();
			    
			   con = DriverManager.getConnection(p.getProperty("jdbc.url"),p.getProperty("jdbc.username"),p.getProperty("jdbc.password"));
			   
			 
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return con;
		
	}
	
	
	public int Reg(DATA d) {
		
		 int w=0;
		
		
		try {
			
		Connection con = Service_wb.mycon();
		
		
			PreparedStatement ps = con.prepareStatement("insert into ownweb values(?,?,?,?,?,?,?)");
			
			ps.setString(1, d.getName());
			ps.setString(2, d.getEmail());
			ps.setString(3, d.getPass());
			ps.setString(4, d.getPhone());
			ps.setString(5, d.getGender());
			ps.setString(6, d.getCourse());
			ps.setString(7, d.getAddress());
			
			w=ps.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return w;
	}
	public Vector login() {
		
		Vector v= new Vector();
		
		
		try {
			
		FileInputStream ff = new FileInputStream("C:\\\\Users\\\\USER\\\\eclipse-workspace\\\\WEB\\\\src\\\\main\\\\java\\\\WEB_SITE\\\\jdbc.properties");
		Properties p= new Properties();
		p.load(ff);
		
		Class.forName(p.getProperty("jdbc.driver")).newInstance();
		 RowSetFactory rf= RowSetProvider.newFactory();
		   
		   JdbcRowSet jr=rf.createJdbcRowSet();
		   
		   jr.setUrl(p.getProperty("jdbc.url"));
		   jr.setUsername(p.getProperty("jdbc.username"));
		   jr.setPassword(p.getProperty("jdbc.password"));
		   
		   jr.setCommand("select email,pass from ownweb"); //and pass=? and phone=?");
		   
           jr.execute();
           
           for(;jr.next();) {
        	   v.add(jr.getString("email"));
        	   v.add(jr.getString("pass"));
        	   
           }
		
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return v;
	}
}
